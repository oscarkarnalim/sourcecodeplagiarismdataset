
public class L3 {

    public static void main(String[] args) {
        int mil = 0 ;
        System.out.println("Miles\t\tKilometers");
        
        System.out.println("-------------------------------");

        mil = 1;

        while (mil <= 10) {

            System.out.println(mil + "\t\t" + mil * 1.609);
            mil++;

        }

    }
}
