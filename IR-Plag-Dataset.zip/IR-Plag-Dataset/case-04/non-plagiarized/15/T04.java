

/**
 *
 * @author FD820A2B4461BDDD116C1518BC4B0F77 871C87F67A53ECC7201FF41AF0A05032
 */
public class T04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int mil = 1609;
        System.out.println("Miles\tKilometers");
        for(int i=1;i<=10;i++){
            System.out.println(i + "\t" + i*mil);
        }
    }
    
}
