

/**
 *
 * @author Elvark
 */
public class No4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int mil = 1609;
        System.out.println("Miles\tKilometers");
        for(int i=1;i<=10;i++){
            System.out.println(i + "\t" + i*mil);
    }
    }
    
}
