/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 6ED61D4B80BB0F81937B32418E98ADCA A94652AA97C7211BA8954DD15A3CF838
 */
public class T04 {
    public static void main(String[] args) {
        System.out.println("miles \t kilometers");
        for (int i = 0; i < 10; i++) {
            System.out.println(i+1+"\t"+((i+1)*1.609));
        }
    }
}
