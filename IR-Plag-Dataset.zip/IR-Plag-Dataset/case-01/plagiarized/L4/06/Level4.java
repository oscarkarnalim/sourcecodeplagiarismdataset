/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author FD8DBE9073AFCC0504CD6901E1091CAD
 */
public class Level4 {

    public static void main(String[] args) {
        String kal = "Welcome to Java";
        tampil(kal);
    }

    //fungsi menampilkan kalimat
    private static void tampil(String kalimat) {
        System.out.println(kalimat);
        System.out.println(kalimat);
        System.out.println(kalimat);
        System.out.println(kalimat);
        System.out.println(kalimat);
    }
}
