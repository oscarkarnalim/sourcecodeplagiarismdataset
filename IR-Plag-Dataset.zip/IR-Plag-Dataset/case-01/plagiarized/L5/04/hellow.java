
public class hellow {

    public static void main(String[] args) {
        printHello();

    }

    private static void printHello() {
        System.out.print("Welcome to Java \n"); //ini buat ngeprint
        System.out.print("Welcome to Java \n"); //ini buat ngeprint lagi
        System.out.print("Welcome to Java \n"); //ini buat ngeprint lagi lagi
        System.out.print("Welcome to Java \n"); //ini buat ngeprint lagi lagi lagi
        System.out.print("Welcome to Java \n"); //ini buat ngeprint lagi lagi lagi lagi
    }

}
